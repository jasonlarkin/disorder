This file replaces standard "EMin.exe" in XenoView directory if eigenvectors are calculated
for thermal diffusivity analysis.
In standard EMin.exe  file *.eig contains eigenvectors NORMALIZED to
the square root of atom mass to provide correct relative AMPLITUDE of oscillation
for atoms with different masses
For calculation of thermal diffusivities, we need RAW eigenvectors NORMALIZED to 1
i.e. the sum of squared length of all vectors must be 1, and not normalized to masses - 
as it was calculated by LAPACK        
